'use strict';

module.context.use('/documentsjpl', require('./routes/documentsjpl'), 'documentsjpl');
